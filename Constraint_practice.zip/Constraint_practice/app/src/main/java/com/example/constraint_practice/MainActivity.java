package com.example.constraint_practice;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import static java.lang.Integer.parseInt;

public class MainActivity extends AppCompatActivity {

    EditText t1,t2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1 = findViewById(R.id.editText_input1);
        t2 = findViewById(R.id.editText_input2);
    }
    public void toSquare(View v)
    {
        int r = parseInt(t1.getText().toString());
        int a=r*r;
        String rr=Integer.toString(a);
        t2.setText(rr);
    }
    public void toNumber(View v)
    {
        int x = Integer.parseInt(t2.getText().toString());
        double b=Math.sqrt(x);
        String xx=Double.toString(b);
        t1.setText(xx);
    }
}