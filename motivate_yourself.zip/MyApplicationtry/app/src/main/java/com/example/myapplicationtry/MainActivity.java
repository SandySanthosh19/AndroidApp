package com.example.myapplicationtry;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {
    MediaPlayer all_is_found_song;
    Button button_play_ref;
    Button button_pause_ref;
    Button button_start_Over_ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        all_is_found_song=MediaPlayer.create(this,R.raw.all_is_found);
        button_play_ref=findViewById(R.id.button_play);
        button_pause_ref=findViewById(R.id.button_pause);
        button_start_Over_ref=findViewById(R.id.button_startOver);
        /*Button button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                EditText MilesEnter = findViewById(R.id.MilesEnter);
                EditText KMEnter = findViewById(R.id.KMEnter);
                double mil = parseDouble(MilesEnter.getText().toString());
                                           //double km=Double.ValueOf(KMEnter.getText().toString());
                double MilesVal = mil / 0.62137;
                DecimalFormat forVal = new DecimalFormat("##.##");
                KMEnter.setText(forVal.format(MilesVal));
            }
        });
        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText MilesEnter = findViewById(R.id.MilesEnter);
                EditText KMEnter = findViewById(R.id.KMEnter);
                double km = parseDouble(KMEnter.getText().toString());
                double KiloVal = km * 0.62137;
                DecimalFormat forVal = new DecimalFormat("##.##");
                MilesEnter.setText(forVal.format(KiloVal));
            }
        });*/
    }
    int resume_position;
    public void playSong(View v)
    {
        all_is_found_song.start();
        resume_position= all_is_found_song.getCurrentPosition();
        button_start_Over_ref.setVisibility(View.VISIBLE);
        button_play_ref.setVisibility(View.GONE);
        button_pause_ref.setVisibility(View.VISIBLE);
    }
    public void pauseSong(View v)
    {
        if(all_is_found_song.isPlaying()) {
            all_is_found_song.pause();
            button_play_ref.setVisibility(View.VISIBLE);
        }
        else
        {
            if(resume_position!=0)
            all_is_found_song.start();
        }
    }
    public void anotherPage(View v)
    {
        Intent for_main2activity=new Intent();
        for_main2activity.setClass(this,Main2Activity.class);
        startActivity(for_main2activity);
    }
    public void startFront(View v)
    {
        if(!all_is_found_song.isPlaying())
        {
            all_is_found_song.seekTo(0);
            all_is_found_song.start();
            button_play_ref.setVisibility(View.INVISIBLE);
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Do not start over music while playing ",Toast.LENGTH_LONG).show();
        }

    }
}
