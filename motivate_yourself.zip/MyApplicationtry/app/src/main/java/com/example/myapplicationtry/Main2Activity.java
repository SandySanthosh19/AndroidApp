package com.example.myapplicationtry;
import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.MediaController;
import android.widget.VideoView;

public class Main2Activity extends AppCompatActivity {
    VideoView vid;
    WebView wb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_2);
        vid=findViewById(R.id.videoView_sample);
        wb=findViewById(R.id.web_view_sample);
        wb.loadUrl("file:///android_asset/motivate.html");
        String first_vid="android.resource://"+getPackageName()+'/'+R.raw.let_it_go;
        Uri uri=Uri.parse(first_vid);
        vid.setVideoURI(uri);
        MediaController med_con = new MediaController(this);
        vid.setMediaController(med_con);
        med_con.setAnchorView(vid);
    }
}
