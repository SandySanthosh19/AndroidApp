package com.example.miles_km;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

import static java.lang.Double.parseDouble;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button1 = findViewById(R.id.button1);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                EditText MilesEnter = findViewById(R.id.ET1);
                EditText KMEnter = findViewById(R.id.ET2);
                double mil = parseDouble(MilesEnter.getText().toString());
                                           //double km=Double.ValueOf(KMEnter.getText().toString());
                double MilesVal = mil / 0.62137;
                DecimalFormat forVal = new DecimalFormat("##.##");
                KMEnter.setText(forVal.format(MilesVal));
            }
        });
        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText MilesEnter = findViewById(R.id.ET1);
                EditText KMEnter = findViewById(R.id.ET2);
                double km = parseDouble(KMEnter.getText().toString());
                double KiloVal = km * 0.62137;
                DecimalFormat forVal = new DecimalFormat("##.##");
                MilesEnter.setText(forVal.format(KiloVal));
            }
        });
    }
}
